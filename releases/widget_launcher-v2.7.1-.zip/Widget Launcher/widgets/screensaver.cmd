@echo off
setlocal enabledelayedexpansion

echo Available Screensavers:
echo.

set "scr_path=C:\Windows\System32"
set /a count=0

for %%f in ("%scr_path%\*.scr") do (
    set /a count+=1
    set "scr[!count!]=%%f"
    echo !count!. %%~nxf
)

if %count%==0 (
    echo No screensavers found.
    pause
    exit /b
)

echo.
set /p choice=Select a screensaver number: 

if not defined scr[%choice%] (
    echo Invalid choice.
    pause
    exit /b
)

echo Launching screensaver...
start "" "!scr[%choice%]!" /s
exit /b
