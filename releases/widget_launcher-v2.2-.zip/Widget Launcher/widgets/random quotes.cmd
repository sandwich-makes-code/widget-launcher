@echo off
title Random Quote
chcp 65001 >nul
setlocal enabledelayedexpansion

:: Check for quotes file 
if not exist "%~dp0neededresources\quotes.txt" (
    cls
    echo ============================
    echo        Random Quote
    echo ============================
    echo.
    echo No quotes\quotes.txt found.
    echo.
    pause
    exit /b
)

:: Count lines
set count=0
for /f "usebackq delims=" %%a in ("%~dp0neededresources\quotes.txt") do (
    set /a count+=1
    set line!count!=%%a
)

:: Pick random line
set /a pick=%random% %% count + 1

cls
echo ============================
echo        Random Quote
echo ============================
echo.
echo !line%pick%!
echo.
pause
