import os
print("Widget To Desktop")
print("1. ░░░░Start░░░ ")
print("2. ░░░░Exit ░░░")
print("Delete Widget (3)")
print("Custom widgetsput in the 'custom_widgets' folder will be automatically be added to the widgets folder.")
option_select = input("Select an option: ")
if option_select == "1":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    WIDGETS_DIR = os.path.join(BASE_DIR, "widgets")
    custom_WIDGETS_DIR = os.path.join(BASE_DIR, "custom_widgets")
    os.system(f'copy "{custom_WIDGETS_DIR}\\*" "{WIDGETS_DIR}\\"')
    if not os.path.exists(WIDGETS_DIR):
        print("Sorry, but the folder 'widgets' does not exist. Ask the vendor for a real copy of this program.")
        exit()
    widgets = [f for f in os.listdir(WIDGETS_DIR) if os.path.isfile(os.path.join(WIDGETS_DIR, f))]
    print("Available widgets:")
    for i, w in enumerate(widgets):
        print(f"{i+1}. {w}")

    choice = input("\nEnter the widget name or number: ").strip()

    if choice.isdigit():
      index = int(choice) - 1
      if 0 <= index < len(widgets):
         widget = widgets[index]
      else:
         print("Invalid number.")
         exit()
    else:
       # If they typed the filename
       if choice in widgets:
          widget = choice
       else:
          print("Widget not found.")
          exit()
    widget_path = os.path.join(WIDGETS_DIR, widget)
    os.system(f'"{widget_path}"')
elif option_select == "2":
    print ("Just to clarify, you are exiting the program?")
    exit_to_confirm_hehe = input("Press Enter to continue, or any other key to cancel. ")
    if exit_to_confirm_hehe == "":
       print ("Exiting...")
       exit()
    else:
       print ("Returning to menu...")
       os.system(f'"{__file__}"')
       exit()
elif option_select == "3":
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))
    WIDGETS_DIR = os.path.join(BASE_DIR, "widgets")
    print("You may have seen your custom widgets get copied to the widgets folder, so I added a file remover to remove files. In the widgets folder.")
    delete_files = input ("Delete what file? Type the name of the file you want to delete. ")
    if delete_files not in os.listdir(WIDGETS_DIR):
     print("File not found.")
     os.system(f'"{__file__}"')
     exit()
    os.system(f'del "{WIDGETS_DIR}\\{delete_files}"')
    print("Deleted.")
    print("Returning to menu...")
    os.system(f'"{__file__}"')
    exit()
