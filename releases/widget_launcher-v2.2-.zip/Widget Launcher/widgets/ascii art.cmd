@echo off
title ASCII Art
chcp 65001 >nul

cls
echo Put your ASCII Art in art.txt.
echo ============================
echo          ASCII Art
echo ============================
echo.

if exist "%~dp0neededresources\art.txt" (
    type "%~dp0neededresources\art.txt"
) else (
    echo No art.txt found.
    echo Create one in neededresources.
)

echo.
pause
