@echo off
title Stopwatch
chcp 65001 >nul
setlocal enabledelayedexpansion

set hh=0
set mm=0
set ss=0

:loop
cls
echo ============================
echo          Stopwatch
echo ============================
echo.

:: Format display values WITHOUT modifying counters
set dhh=0!hh!
set dmm=0!mm!
set dss=0!ss!

set dhh=!dhh:~-2!
set dmm=!dmm:~-2!
set dss=!dss:~-2!

echo        !dhh!:!dmm!:!dss!
echo.
echo Press CTRL+C to stop.

timeout /t 1 >nul

:: Increment counters
set /a ss+=1
if !ss! GEQ 60 (
    set ss=0
    set /a mm+=1
)

if !mm! GEQ 60 (
    set mm=0
    set /a hh+=1
)

goto loop
