@echo off
for /f "delims=" %%a in ('echo prompt $E^| cmd') do set "ESC=%%a"
echo %ESC%[44m LOADING... %ESC%[0m
timeout /t 2 >nul
cls
cd /d "%~dp0"
python widget_launcher_script.py
pause
