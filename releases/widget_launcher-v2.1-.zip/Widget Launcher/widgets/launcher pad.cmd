@echo off
title Launcher Pad
chcp 65001 >nul

:loop
cls
echo ============================
echo         Launcher Pad
echo ============================
echo Type any command, file, or path:
echo (Examples: notepad, calc, chrome, C:\Folder)
echo.
set /p cmd=Run: 

if "%cmd%"=="" goto loop

start "" "%cmd%" 2>nul || (
    echo.
    echo Failed to launch "%cmd%".
    echo Make sure it exists or is in PATH.
    echo.
    pause
)

goto loop
