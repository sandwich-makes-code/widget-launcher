@echo off
title Countdown Timer
chcp 65001 >nul
setlocal enabledelayedexpansion

cls
echo ============================
echo       Countdown Timer
echo ============================
echo.
set /p total=Enter seconds to count down: 

:: Validate input
for /f "delims=0123456789" %%x in ("%total%") do (
    echo.
    echo Invalid number.
    pause
    exit /b
)

:loop
cls
echo ============================
echo       Countdown Timer
echo ============================
echo.

:: Stop when finished
if %total% LEQ 0 (
    echo        00:00:00
    echo.
    echo Time's up!
    echo.
    pause
    exit /b
)

:: Convert total seconds → HH MM SS
set /a hh=%total%/3600
set /a mm=(%total% %% 3600)/60
set /a ss=%total% %% 60

:: Format display values
set dhh=0!hh!
set dmm=0!mm!
set dss=0!ss!

set dhh=!dhh:~-2!
set dmm=!dmm:~-2!
set dss=!dss:~-2!

echo        !dhh!:!dmm!:!dss!
echo.
echo Press CTRL+C to stop early.

timeout /t 1 >nul
set /a total-=1
goto loop
