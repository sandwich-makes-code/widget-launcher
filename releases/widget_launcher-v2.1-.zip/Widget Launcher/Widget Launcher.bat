@echo off
cd /d "%~dp0"
python widget_launcher_script.py
pause
