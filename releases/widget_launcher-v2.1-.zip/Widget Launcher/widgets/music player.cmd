
@echo off
title Music Player
chcp 65001 >nul
setlocal enabledelayedexpansion

:scan
cls
echo ============================
echo         Music Player
echo ============================
echo.
echo Scanning for music files...
echo.

set i=0
for %%f in ("%~dp0*.mp3" "%~dp0*.wav") do (
    set /a i+=1
    set file!i!=%%~nxf
)

if %i%==0 (
    echo No .mp3 or .wav files found in this folder.
    echo.
    echo Drop music files next to this widget.
    echo.
    pause
    exit /b
)

echo Found %i% file(s):
echo.

for /l %%n in (1,1,%i%) do (
    echo %%n. !file%%n!
)

echo.
set /p choice=Select a number to play: 

:: Validate numeric input
for /f "delims=0123456789" %%x in ("%choice%") do (
    echo.
    echo Invalid selection.
    pause
    goto scan
)

if %choice% LSS 1 goto scan
if %choice% GTR %i% goto scan

set selected=!file%choice%!

cls
echo ============================
echo         Music Player
echo ============================
echo.
echo Playing: %selected%
echo.

start "" "%~dp0%selected%"

echo.
pause
exit /b
