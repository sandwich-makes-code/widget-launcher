@echo off

:: Set font to Consolas 12x12 (square-ish)
reg add "HKCU\Console\%~n0" /v FaceName /t REG_SZ /d Consolas /f >nul
reg add "HKCU\Console\%~n0" /v FontSize /t REG_DWORD /d 0x000c0000 /f >nul

:: Resize window
mode con: cols=40 lines=20

:loop
cls
echo        Current Time
echo ---------------------------
time /t
timeout /t 1 >nul
goto loop
