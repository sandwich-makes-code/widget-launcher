@echo off
title Weather
chcp 65001 >nul

cls
echo ============================
echo          Weather
echo ============================
echo.

curl wttr.in/?format=3

echo.
pause
