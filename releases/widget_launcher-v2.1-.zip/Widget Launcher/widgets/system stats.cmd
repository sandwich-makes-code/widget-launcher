@echo off
title System Stats
chcp 65001 >nul

:loop
cls
echo ============================
echo        System Stats
echo ============================

echo CPU Load:
wmic cpu get loadpercentage | findstr /r "[0-9]"

echo.
echo RAM Usage:
wmic OS get FreePhysicalMemory,TotalVisibleMemorySize /Value

echo.
echo Disk Space (C:):
wmic logicaldisk where "DeviceID='C:'" get FreeSpace,Size /Value

echo.
echo Uptime:
wmic os get lastbootuptime

echo.
echo Refreshing in 3 seconds...
timeout /t 3 >nul
goto loop
